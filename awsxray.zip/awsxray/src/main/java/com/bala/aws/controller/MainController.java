package com.bala.aws.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.xray.spring.aop.XRayEnabled;

@RestController
@XRayEnabled
@RequestMapping("/api")
public class MainController {

    
    @GetMapping("/trace")
    public String getTraceId() {
        
        return "started";
    }
}
