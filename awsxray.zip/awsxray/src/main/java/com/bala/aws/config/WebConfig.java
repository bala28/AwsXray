package com.bala.aws.config;

import java.net.URL;

import javax.servlet.Filter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.auth.profile.ProfilesConfigFile;
import com.amazonaws.services.xray.AWSXRayClientBuilder;
import com.amazonaws.xray.AWSXRay;
import com.amazonaws.xray.AWSXRayRecorder;
import com.amazonaws.xray.AWSXRayRecorderBuilder;
import com.amazonaws.xray.handlers.TracingHandler;
import com.amazonaws.xray.javax.servlet.AWSXRayServletFilter;
import com.amazonaws.xray.plugins.EC2Plugin;
import com.amazonaws.xray.plugins.ElasticBeanstalkPlugin;
import com.amazonaws.xray.strategy.FixedSegmentNamingStrategy;
import com.amazonaws.xray.strategy.sampling.LocalizedSamplingStrategy;

@Configuration
public class WebConfig {
    
    @Bean
    public Filter tracingFilter() {
      return new AWSXRayServletFilter(new FixedSegmentNamingStrategy("balaXRayTest"));
    }

    @Bean
    public Filter simpleCORSFilter() {
      return new SimpleCORSFilter();
    }
    
    
   
    @Bean
    public com.amazonaws.services.xray.AWSXRay awsClientBuilder() {
         ProfilesConfigFile profile = new ProfilesConfigFile();
         ProfileCredentialsProvider provider = new ProfileCredentialsProvider(profile,"eis-deliverydevqa"); 
      /* return AmazonS3ClientBuilder.standard()
        .withCredentials(provider)
        .withRegion("us-east-1")
        .
        .enablePathStyleAccess()
        .build();*/
       
       return AWSXRayClientBuilder.standard().withRegion("us-east-1").withCredentials(provider)
      //.withMetricsCollector(metrics)
       .withRequestHandlers(new TracingHandler(awsXray())).build();
    }
    
    
    
    
    @Bean
    public AWSXRayRecorder awsXray() {
        AWSXRayRecorderBuilder builder = AWSXRayRecorderBuilder.standard();
                
               // .withPlugin(new EC2Plugin()).withPlugin(new ElasticBeanstalkPlugin());

        URL ruleFile = WebConfig.class.getResource("/sampling-rules.json");
        builder.withSamplingStrategy(new LocalizedSamplingStrategy(ruleFile));

        AWSXRay.setGlobalRecorder(builder.build());

        AWSXRay.beginSegment("bala-init");

        AWSXRay.endSegment();
        return builder.build();
    }
    
    
    
    

}
